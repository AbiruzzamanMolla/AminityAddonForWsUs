<?php

return [
    'name' => 'Aminity',
];
